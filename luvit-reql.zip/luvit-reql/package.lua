return {
	name = 'DannehSC/think-luvit',
	version = '1.0.0',
	homepage = 'https://github.com/DannehSC/luvit-reql',
	dependencies = {
		'creationix/coro-net@3.0.0',
		
	},
	tags = {'luvit', 'rethinkdb'},
	license = 'none',
	authors = {
		'DannehSC',
		'SinisterRectus',
		'kev1ns',
		'JohnnyMorganz',
		'Tigerism'
	}
	files = {'**.lua'},
}